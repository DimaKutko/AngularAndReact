import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-weather',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.css']
})
export class WeatherComponent implements OnInit {

  myForm!: FormGroup;

  constructor(private __fb: FormBuilder) { }

  ngOnInit(): void {
    this.myForm = this.__fb.group({
      cityName: ['', Validators.required]
    });
  }

  saveForm(form:FormGroup){
    console.log('Valide: ', form.valid);
    console.log('CityName: ', form.value.cityName);
  }

}
